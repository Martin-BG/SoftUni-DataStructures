# SoftUni-Data-Structures-Algorithms-May-2017
Repository created for educational purposes. 

The main usage is to store all code written during practical exercises for Data Structures and Algorithms Course at SoftUni.

Trainers: Peter Penev, Simeon Sheytanov, Vasil Gramov

Organization: SoftUni
