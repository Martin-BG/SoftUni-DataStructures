﻿namespace BunnyWars.Core
{
    class BunnyWarsTestingGround
    {
        static void Main(string[] args)
        {
        }
    }
}
