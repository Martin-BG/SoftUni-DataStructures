import java.util.List;

public class BinaryHeap<T extends Comparable<T>> {

    private List<T> heap;
    private int size;

    public BinaryHeap() {
        throw new UnsupportedOperationException();
    }

    public int size() {
        return this.size;
    }

    public void insert(T element) {
        throw new UnsupportedOperationException();
    }

    public T peek() {
        throw new UnsupportedOperationException();
    }

    public T pull() {
        throw new UnsupportedOperationException();
    }
}
