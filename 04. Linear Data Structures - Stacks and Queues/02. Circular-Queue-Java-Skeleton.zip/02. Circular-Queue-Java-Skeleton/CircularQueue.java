public class CircularQueue<E> {

    private int size;

    public CircularQueue() {
        // TODO
    }

    public CircularQueue(int initialCapacity) {
        // TODO
    }

    public int size() {
        return this.size;
    }

    private  void setSize(int size) {
        this.size = size;
    }

    public void enqueue(E element) {
        // TODO
    }

    public E dequeue() {
        // TODO
        throw new UnsupportedOperationException();
    }

    public E[] toArray() {
        // TODO
        throw new UnsupportedOperationException();
    }

}
