package tests.types;

public interface PerformanceTests {
}
