package tests.types;

public interface CorrectnessTests {
}
