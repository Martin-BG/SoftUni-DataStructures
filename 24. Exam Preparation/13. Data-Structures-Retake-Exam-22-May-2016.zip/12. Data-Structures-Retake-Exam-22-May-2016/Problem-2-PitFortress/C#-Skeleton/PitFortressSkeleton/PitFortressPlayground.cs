﻿namespace PitFortress
{
    public class PitFortressPlayground
    {
        public static void Main()
        {
        }
    }
}
