package test.categories;

public interface Correctness {
}
