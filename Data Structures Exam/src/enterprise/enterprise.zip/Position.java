public enum Position {

    DEVELOPER, MANAGER, HR, TEAM_LEAD, OWNER;
}
