import java.util.Iterator;
import java.util.UUID;

public class Enterprise implements IEnterprise {


    @Override
    public void add(Employee employee) {

    }

    @Override
    public boolean contains(UUID id) {
        return false;
    }

    @Override
    public boolean contains(Employee employee) {
        return false;
    }

    @Override
    public boolean change(UUID id, Employee employee) {
        return false;
    }

    @Override
    public boolean fire(UUID id) {
        return false;
    }

    @Override
    public boolean raiseSalary(int months, int percent) {
        return false;
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Employee getByUUID(UUID id) {
        return null;
    }

    @Override
    public Position positionByUUID(UUID id) {
        return null;
    }

    @Override
    public Iterable<Employee> getByPosition(Position position) {
        return null;
    }

    @Override
    public Iterable<Employee> getBySalary(double minSalary) {
        return null;
    }

    @Override
    public Iterable<Employee> getBySalaryAndPosition(double salary, Position position) {
        return null;
    }

    @Override
    public Iterable<Employee> searchBySalary(double minSalary, double maxSalary) {
        return null;
    }

    @Override
    public Iterable<Employee> searchByPosition(Iterable<Position> positions) {
        return null;
    }

    @Override
    public Iterable<Employee> allWithPositionAndMinSalary(Position position, double minSalary) {
        return null;
    }

    @Override
    public Iterable<Employee> searchByFirstName(String firstName) {
        return null;
    }

    @Override
    public Iterable<Employee> searchByNameAndPosition(String firstName, String lastName, Position position) {
        return null;
    }

    @Override
    public Iterator<Employee> iterator() {
        return null;
    }
}
